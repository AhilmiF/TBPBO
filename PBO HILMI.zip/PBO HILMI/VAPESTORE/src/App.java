import java.text.SimpleDateFormat;
import java.util.Scanner;
import java.util.Date;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner terminalInput = new Scanner(System.in);
        String pilihanUser;
        boolean isLanjutkan = true;

        //Objek untuk menjalankan method
        Admin admin = new Admin();
        Login adm = new Login();
        //melakukan login
        adm.login();

        //perulangan untuk menampilkan menu aplikasi
        while (isLanjutkan) {
            clearScreen();
            System.out.println("Database Hilmi Store\n");

            Date date = new Date();
            SimpleDateFormat hari = new SimpleDateFormat("'Hari/Tanggal \t:' EEEEEEEEEE dd-mm-yy");
            SimpleDateFormat jam =  new SimpleDateFormat("'Waktu \t\t:' hh:mm:ss z");
            
            System.out.println(hari.format(date));
            System.out.println(jam.format(date));
            System.out.println("1.\tTambah Produk");
            System.out.println("2.\tRestock Produk");
            System.out.println("3.\tHapus Produk");
            System.out.println("4.\tPrint Stok");
            System.out.println("5.\tKeluar");

            System.out.print("\n\nPilihan anda: ");
            pilihanUser = terminalInput.next();

            //memilih fitur yang akan dijalankan
            switch (pilihanUser) {
                case "1":
                    clearScreen();
                    System.out.println("\n==============================");
                    System.out.println("     TAMBAH PRODUK      ");
                    System.out.println("==============================");
                    admin.tambah();
                    break;
                case "2":
                    clearScreen();
                    System.out.println("\n==============================");
                    System.out.println("     RESTOCK    ");
                    System.out.println("==============================");
                    admin.update();
                    admin.show();
                    break;
                case "3":
                    clearScreen();
                    System.out.println("\n==============================");
                    System.out.println("     HAPUS PRODUK      ");
                    System.out.println("==============================");
                    admin.delete();
                    break;
                case "4":
                    clearScreen();
                    System.out.println("\n==============================");
                    System.out.println("     PRINT STOK     ");
                    System.out.println("==============================");
                    admin.show();
                    break;    
                case "5":
                    clearScreen();
                    System.out.println("\n==============================");
                    System.out.println("ANDA TELAH KELUAR, SILAHKAN LOGIN KEMBALI");
                    System.out.println("==============================");
                    System.exit(0);
                    break;
                default:
                    System.err.println("\nInput anda tidak ditemukan\nSilahkan pilih [1-5]");
            }

            isLanjutkan = admin.getYesorNo("Apakah Anda ingin melanjutkan");
        }

    }
        //method untuk membersihkan terminal
        private static void clearScreen(){
        try {
            if (System.getProperty("os.name").contains("Windows")){
                new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
            } else {
                System.out.print("\033\143");
            }
        } catch (Exception ex){
            System.err.println("tidak bisa clear screen");
        }
        
    }
}
