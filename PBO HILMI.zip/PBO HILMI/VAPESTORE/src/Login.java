import java.util.HashMap;
import java.util.Scanner;

public class Login extends Admin {
    // Method untuk login
    public void login() {
        // Implementasi HashMap untuk proses login
        HashMap<String, String> login = new HashMap<>();

        // Menambahkan data user dan password
        login.put("admin", "password");

        System.out.println("oooooooooo LOGIN oooooooooooo");

        Scanner scannerInput = new Scanner(System.in);

        boolean isLoginSuccessful = false;

        while (!isLoginSuccessful) {
            System.out.print("Username : ");
            String username = scannerInput.nextLine();
            System.out.print("Password : ");
            String password = scannerInput.nextLine();

            // Validasi login
            if (login.containsKey(username) && login.get(username).equals(password)) {
                isLoginSuccessful = true;
                System.out.println("LOGIN BERHASIL, SELAMAT DATANG " + username);
            } else {
                System.err.println("LOGIN GAGAL, SILAHKAN LOGIN KEMBALI\n");
            }
        }
    }
}
