import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Admin implements CRUD {

    // koneksi database
    public String driver = "com.mysql.jdbc.Driver"; // driver jdbc
    public String url = "jdbc:mysql://localhost:3306/tugasbesar"; // url untuk melakukan connect ke db
    public String user = "root";
    public String pass = "";

    //eksekusi database
    public Connection conn;
    public Statement stat;
    public ResultSet result;

    Scanner scanInt = new Scanner(System.in);
    Scanner scanStr = new Scanner(System.in);

    //method koneksi ke database
    @Override
    public void connect() {
        try {
            conn = DriverManager.getConnection(url, user, pass);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // method untuk menambah produk
    @Override
    public void tambah() {
        connect(); // melakukan koneksi
        try {

            stat = conn.createStatement();

            System.out.print("Kode Liquid\t\t: ");
            String kodeLiq = scanStr.nextLine();

            System.out.print("Masukkan Nama brewery\t: ");
            String brewery = scanStr.nextLine();

            System.out.print("Masukkan nama liquid\t: ");
            String namaLiq = scanStr.nextLine();

            System.out.print("Masukkan jumlah nicotin\t: ");
            String nic = scanStr.nextLine();

            System.out.print("Masukkan volume liquid\t: ");
            String volume = scanStr.nextLine();

            System.out.print("Masukkan harga\t\t: ");
            Integer harga = scanInt.nextInt();

            System.out.print("Masukkan jumlah stok\t: ");
            Integer stok = scanInt.nextInt();

            String sql = "INSERT INTO liquid (kodeLiq, brewery, namaLiq, nic, volume, harga, jumlah) VALUE ('%s', '%s', '%s', '%s', '%s', %d, %d )";
            sql = String.format(sql, kodeLiq, brewery, namaLiq, nic, volume, harga, stok);
            stat.execute(sql);

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    // method untuk Restock produk
    @Override
    public void update() {
        connect();
        String sql2 = "SELECT * FROM liquid";
        try {

            stat = conn.createStatement();
            result = stat.executeQuery(sql2);

            if (result.next()) {
                Integer stok = result.getInt("jumlah");
                System.out.print("masukkan kode liquid\t: ");
                String kodeLiq = scanStr.nextLine();
                System.out.print("masukkan jumlah restock\t\t: ");
                Integer tambah = scanInt.nextInt();
                Integer hasil = stok + tambah;

                String sql = "UPDATE liquid SET jumlah = %d WHERE kodeLiq = '%s'";
                sql = String.format(sql, hasil, kodeLiq);

                try (Statement updateStatement = conn.createStatement()) {
                    updateStatement.executeUpdate(sql);
                }

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // method untuk menghapus produk
    @Override
    public void delete() {
        connect();
        try {
            stat = conn.createStatement();

            System.out.print("Masukkan kode liquid yang mau di hapus : ");
            String kodeLiq = scanStr.nextLine();

            String sql = String.format("DELETE FROM liquid WHERE kodeLiq = '%s'", kodeLiq);

            stat.execute(sql);
            System.out.println("Data terhapus");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    // method untuk menampilkan stok
    @Override
    public void show() {
        connect();
        String sql = "SELECT * FROM liquid";
        try {
            stat = conn.createStatement();
            result = stat.executeQuery(sql);

            while (result.next()) {
                String kodeLiq = result.getString("kodeLiq");
                String brewery = result.getString("brewery");
                String namaLiq = result.getString("namaLiq");
                String nic = result.getString("nic");
                String volume = result.getString("volume");
                Integer harga = result.getInt("harga");
                Integer stok = result.getInt("jumlah");

                System.out.println(
                        String.format(
                                "kode liquid\t: %s \nbrewery\t\t: %s \nnama liquid\t: %s \njumlah nicotin\t: %s \nvolume\t\t: %s \nharga\t\t: %d  \njumlah stok\t: %d \n ",
                                kodeLiq, brewery,
                                namaLiq, nic, volume, harga, stok));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //Method fungsi boolean untuk konfirmasi
    public boolean getYesorNo(String message){
        Scanner terminalInput = new Scanner(System.in);
        System.out.print("\n"+message+" (y/n)? ");
        String pilihanUser = terminalInput.next();

        //percabangan dan implemantasi method String
        while(!pilihanUser.equalsIgnoreCase("y") && !pilihanUser.equalsIgnoreCase("n")) {
            System.err.println("Pilihan anda bukan y atau n");
            System.out.print("\n"+message+" (y/n)? ");
            pilihanUser = terminalInput.next();
        }

        return pilihanUser.equalsIgnoreCase("y");
    }
    
}
