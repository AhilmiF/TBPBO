public interface CRUD {

    public void update();

    public void tambah();

    public void delete();

    public void show();

    public void connect();
}
